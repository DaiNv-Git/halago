package com.hitex.halago.model.DAO.introduce;

public class Header {
    IntroduceHeader introduceHeader;

    public Header(IntroduceHeader introduceHeader) {
        this.introduceHeader = introduceHeader;
    }

    public IntroduceHeader getIntroduceHeader() {
        return introduceHeader;
    }

    public void setIntroduceHeader(IntroduceHeader introduceHeader) {
        this.introduceHeader = introduceHeader;
    }
}
