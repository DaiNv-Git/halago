package com.hitex.halago.model.DAO.introduce;

public class IntroduceFooter {

      private int id;

    private SeoImg img;

    private String content;

    private String content_en;

    private int status;

    private String statusName;

    private int type;

    private String typeName;

    private String totalInfluencer;

    private String totalKols;

    private String totalStar;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public SeoImg getImg() {
        return img;
    }

    public void setImg(SeoImg img) {
        this.img = img;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getStatusName() {
        return statusName;
    }

    public void setStatusName(String statusName) {
        this.statusName = statusName;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getTypeName() {
        return typeName;
    }

    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }

    public String getTotalInfluencer() {
        return totalInfluencer;
    }

    public void setTotalInfluencer(String totalInfluencer) {
        this.totalInfluencer = totalInfluencer;
    }

    public String getTotalKols() {
        return totalKols;
    }

    public void setTotalKols(String totalKols) {
        this.totalKols = totalKols;
    }

    public String getTotalStar() {
        return totalStar;
    }

    public void setTotalStar(String totalStar) {
        this.totalStar = totalStar;
    }

    public String getContent_en() {
        return content_en;
    }

    public void setContent_en(String content_en) {
        this.content_en = content_en;
    }
}
