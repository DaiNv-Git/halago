package com.hitex.halago.model.DAO.Footer;

import com.hitex.halago.model.Footer;

public class FooterLanguage extends Footer {
    private String address_en;

    private String company_en;

    public String getCompany_en() {
        return company_en;
    }

    public void setCompany_en(String company_en) {
        this.company_en = company_en;
    }

    public String getAddress_en() {
        return address_en;
    }

    public void setAddress_en(String address_en) {
        this.address_en = address_en;
    }
}
