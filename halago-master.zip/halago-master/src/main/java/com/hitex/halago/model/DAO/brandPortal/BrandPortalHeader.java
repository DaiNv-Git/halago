package com.hitex.halago.model.DAO.brandPortal;

import com.hitex.halago.model.DAO.BaseModel;

public class BrandPortalHeader extends BaseModel {
    private String img;

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }
}
