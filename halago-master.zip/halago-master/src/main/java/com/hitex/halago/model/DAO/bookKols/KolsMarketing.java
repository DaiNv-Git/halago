package com.hitex.halago.model.DAO.bookKols;

import com.hitex.halago.model.DAO.BaseModel;

public class KolsMarketing extends BaseModel {

}
