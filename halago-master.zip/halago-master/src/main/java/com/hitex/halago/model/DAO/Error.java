package com.hitex.halago.model.DAO;

public class Error {
    private String content;

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
