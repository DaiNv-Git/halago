import Hand from "./icon_hand.png";
import Up from "./icon_up.png";
import Down from "./icon_down.png";
import Fb from "./icon_fb.png";

export const IconHand = Hand;
export const IconUp = Up;
export const IconDown = Down;
export const IconFb = Fb;
