import Influencer from './Influencer/Influencer';

export default Influencer;