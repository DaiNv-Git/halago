export { default } from "./DetailCI";
