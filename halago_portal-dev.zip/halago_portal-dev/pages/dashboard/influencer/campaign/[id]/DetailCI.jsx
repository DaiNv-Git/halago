import LayoutM from "layouts";
import React from "react";

const DetailCI = () => {
  return <LayoutM>DetailCI</LayoutM>;
};

export default DetailCI;
