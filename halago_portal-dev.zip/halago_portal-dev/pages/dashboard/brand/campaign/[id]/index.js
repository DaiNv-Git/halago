export { default } from "./DetailCB";
