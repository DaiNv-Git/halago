export { default } from "./News";
