export const formQuarter = {
  wrapperCol: { span: 6 },
};

export const formHalf = {
  wrapperCol: { span: 12 },
};

export const formThreeQuarter = {
  wrapperCol: { span: 18 },
};

export const formLabel = {
  labelCol: { offset: 2, span: 18 },
  wrapperCol: { offset: 2, span: 18 },
};
