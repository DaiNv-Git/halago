export const baseRule = [{ required: true, message: "Không được để trống !!!" }];
