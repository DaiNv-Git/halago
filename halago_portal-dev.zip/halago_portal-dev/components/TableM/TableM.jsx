import React from "react";
import { Table } from "antd";

const TableM = (props) => {
  return <Table bordered size="small" {...props} />;
};

export default TableM;
