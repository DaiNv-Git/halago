package com.hitex.halago.model.DAO.introduce;

import com.hitex.halago.model.DAO.introduce.IntroduceBrandDeployment;

public class BrandDeployment {
    IntroduceBrandDeployment introduceBrandDeployment;

    public BrandDeployment(IntroduceBrandDeployment introduceBrandDeployment) {
        this.introduceBrandDeployment = introduceBrandDeployment;
    }

    public IntroduceBrandDeployment getIntroduceBrandDeployment() {
        return introduceBrandDeployment;
    }

    public void setIntroduceBrandDeployment(IntroduceBrandDeployment introduceBrandDeployment) {
        this.introduceBrandDeployment = introduceBrandDeployment;
    }
}
