package com.hitex.halago.repository;

import com.hitex.halago.model.Personal;
import org.springframework.data.repository.CrudRepository;

public interface PersonalInfoRepository extends CrudRepository<Personal,String> {

}
