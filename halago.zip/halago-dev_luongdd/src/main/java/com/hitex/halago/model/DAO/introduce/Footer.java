package com.hitex.halago.model.DAO.introduce;

public class Footer {
    IntroduceFooter introduceFooter;

    public Footer(IntroduceFooter introduceFooter) {
        this.introduceFooter = introduceFooter;
    }

    public IntroduceFooter getIntroduceFooter() {
        return introduceFooter;
    }

    public void setIntroduceFooter(IntroduceFooter introduceFooter) {
        this.introduceFooter = introduceFooter;
    }
}
