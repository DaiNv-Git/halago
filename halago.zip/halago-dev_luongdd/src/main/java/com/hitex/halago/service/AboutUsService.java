package com.hitex.halago.service;

import com.hitex.halago.model.AboutUs;
import com.hitex.halago.model.DAO.AboutUs.AboutUsDao;

public interface AboutUsService {
    AboutUsDao getAboutUs(String language);
    AboutUsDao getVision(String language);
}
