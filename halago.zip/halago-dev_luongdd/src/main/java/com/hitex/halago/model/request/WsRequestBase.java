package com.hitex.halago.model.request;

public class WsRequestBase {
    private String siRes;

    public String getSiRes() {
        return siRes;
    }

    public void setSiRes(String siRes) {
        this.siRes = siRes;
    }
}
