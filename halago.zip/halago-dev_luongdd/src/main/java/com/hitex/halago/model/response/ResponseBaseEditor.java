package com.hitex.halago.model.response;

/**
 * @author Chidq
 * @project halago
 * @created 06/04/2021 - 3:39 PM
 */
public class ResponseBaseEditor extends ResponseBase {
    private int uploaded;
    private String fileName;
}
